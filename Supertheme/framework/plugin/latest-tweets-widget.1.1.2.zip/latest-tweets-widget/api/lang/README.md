# Translating Twitter API Wordpress Plugin

Translations are in their infancy for this project. 
If you'd like to translate this plugin into your language, please [get in touch](https://twitter.com/timwhitlock).

Messages here are for the admin screens plus common Twitter-related phrases you might need in your plugin.


### Contributers:

Many thanks to the following translators:

* **pt_BR** [Leandro Dimitrio](http://wordpress.org/support/profile/leandrodimitrio)
* **de_DE** [Florian Felsing](https://twitter.com/FlorianFelsing) and [David Noh](http://wordpress.org/support/profile/david_noh)
* **ru_RU** [Andrey Yakovenko](https://twitter.com/YakovenkoAndrey)
* **nl_NL** [Daniel Wichers](https://twitter.com/dwichers)
